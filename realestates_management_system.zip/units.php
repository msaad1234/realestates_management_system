<?php

include_once "page/header.php";
if (!isset($_SESSION['preLogin']))
    return;
?>


<div id="units" class="row col-sm-12">

    <div id="page-title"><span>الوحدات</span></div><br>

    <div id="list">

        <ul>

            <?php

            $query = mysqli_query($connect, "SELECT * FROM units");
            while ($row = mysqli_fetch_array($query)) {

            ?>

                <a href="unit.php?id=<?php echo $row['id']; ?>">
                    <li><?php echo $row['name']; ?></li>
                </a>

            <?php


            }

            ?>


        </ul>

    </div>



</div>



<?php


include_once "page/footer.php";

?>