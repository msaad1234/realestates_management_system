<footer>

<p>Realestates Managment System ©</p>

</footer>

</div>
</body>

</html>