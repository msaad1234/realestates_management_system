<?php


$host = "localhost";
$username = "root";
$password = "msaad12345";

$connect = mysqli_connect($host, $username, $password);

mysqli_select_db($connect, "realestates");


?>